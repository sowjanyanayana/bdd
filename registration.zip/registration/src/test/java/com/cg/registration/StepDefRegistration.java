package com.cg.registration;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefRegistration {

	WebDriver driver = null;
	RegistrationPageFactory factory = null;

	@Given("^user is in registration page$")
	public void user_is_in_registration_page() throws Exception {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\snayana\\Documents\\chromedriver.exe");
		driver = new ChromeDriver();
		factory = new RegistrationPageFactory(driver);
		driver.get("file:///D:/servlet/jsp/WebContent/register.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Exception {
		String title = driver.getTitle();
		if (title.equals("Registration form")) {

			System.out.println("Title Matched");
		} else {
			System.out.println("you are not in the required page");
		}
		
	}

	@When("^user entered name mismatches the required pattern$")
	public void user_entered_name_mismatches_the_required_pattern() throws Exception {
		factory.setName("so");
		Thread.sleep(1000);
		factory.setButton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("not matched " + alertMessage);
	}

	@Then("^display error message$")
	public void display_error_message() throws Exception {
		driver.close();

	}

	@When("^user does not enter name$")
	public void user_does_not_enter_name() throws Exception {
		factory.setName("");
		Thread.sleep(1000);
		factory.setButton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("not matched " + alertMessage);
	}

	@When("^user enters wrong mobile number$")
	public void user_enters_wrong_mobile_number(DataTable number) throws Exception {
		factory.setName("sowjanya");
		List<String> list = number.asList(String.class);
		String data = null;
		for (String dataTemp : list) {
			data = dataTemp;
			factory.getMobileNumber().clear();
			factory.setMobileNumber(dataTemp);
			Thread.sleep(1000);
			factory.setButton();

			if (Pattern.matches("^[6-9]{1}[0-9]{9}$", data)) {
				System.out.println("Matching ");
			}else {
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
				System.out.println("not matched " + alertMessage);
			}
		}
		//factory.setButton();
	}

	@When("^user enters wrong email id$")
	public void user_enters_wrong_email_id(DataTable number1) throws Exception {

		factory.setName("sowjanya");
		factory.setMobileNumber("9032974524");
		List<String> list = number1.asList(String.class);
		String data = null;
		for (String dataTemp : list) {
			data = dataTemp;
			factory.getEmail().clear();
			factory.setEmail(dataTemp);
			Thread.sleep(1000);
			factory.setButton();

			if (Pattern.matches("^[a-z0-9]{5,}[@][a-z]{1,6}[.][a-z]{2,6}$", data)) {
				System.out.println("Matching ");
			}else {
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
				System.out.println("not matched " + alertMessage);
			}
			
		}
		//factory.setButton();
	}

	@When("^user does not enter address$")
	public void user_does_not_enter_address() throws Exception {
		factory.setName("sowjanya");
		Thread.sleep(1000);
		factory.setMobileNumber("9032974524");
		Thread.sleep(1000);
		factory.setEmail("sowji526@gmail.com");
		Thread.sleep(1000);
		factory.setButton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("not matched " + alertMessage);

	}

	@When("^user enters correct details$")
	public void user_enters_correct_details() throws Exception {
		factory.setName("sowjanya");
		Thread.sleep(1000);
		factory.setMobileNumber("9032974524");
		Thread.sleep(1000);
		factory.setEmail("sowji526@gmail.com");
		Thread.sleep(1000);
		factory.setAddress("chennai");
		Thread.sleep(1000);
		}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Exception {
		factory.setButton();
		System.out.println("successful");
		driver.close();
	}

}
