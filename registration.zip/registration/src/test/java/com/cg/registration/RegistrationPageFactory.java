package com.cg.registration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPageFactory {

	WebDriver d;

	public RegistrationPageFactory(WebDriver driver1) {
		this.d = driver1;
		PageFactory.initElements(d, this);
	}

	public RegistrationPageFactory() {
		super();
	}
	
	@FindBy(name="name")
	@CacheLookup
	WebElement name;
	
	@FindBy(name="mobilenumber")
	@CacheLookup
	WebElement mobileNumber;
	
	@FindBy(name="email")
	@CacheLookup
	WebElement email;
		
	@FindBy(name="address")
	@CacheLookup
	WebElement address;
	
	
	@FindBy(name="submit")
	@CacheLookup
	WebElement button;
	
	
	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name1) {
		name.sendKeys(name1);
	}

	public WebElement getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber1) {
		mobileNumber.sendKeys(mobileNumber1);;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email1) {
		email.sendKeys(email1);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address1) {
		address.sendKeys(address1);
	}	
	
	
}
